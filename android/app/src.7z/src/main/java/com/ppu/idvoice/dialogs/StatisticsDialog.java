package com.ppu.idvoice.dialogs;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ppu.idvoice.R;

public class StatisticsDialog extends DialogFragment {

    public static StatisticsDialog newInstance(Bundle bundle) {
        StatisticsDialog statisticsDialog = new StatisticsDialog();
        statisticsDialog.setArguments(bundle);
        return statisticsDialog;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.dialog_statistics, container, false);

        TextView verificationStatistics = rootView.findViewById(R.id.verificationStatistics);

        int verificationThreshold = 50;

        assert getArguments() != null;
        float verificationScore = getArguments().getFloat("VERIFICATION_SCORE") * 100;

        verificationStatistics.setText(
                String.format(
                        getString(
                                verificationScore > verificationThreshold ?
                                        R.string.verification_successfull :
                                        R.string.verification_failed),
                        verificationScore));

        verificationStatistics.setTextColor(rootView.getContext().getResources().getColor(
                verificationScore > verificationThreshold ? R.color.green : R.color.red));

        return rootView;
    }

    @Override
    public void onStart() {
        super.onStart();
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    }
}

package com.ppu.idvoice;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.tts.Voice;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;

import com.google.gson.Gson;
import com.ppu.idvoice.dialogs.OnStopRecording;
import com.ppu.idvoice.dialogs.RecordDialog;
import com.ppu.idvoice.utils.EngineManager;
import com.ppu.idvoice.utils.Prefs;

import net.idrnd.voicesdk.verify.VerifyResult;
import net.idrnd.voicesdk.core.common.VoiceTemplate;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import io.flutter.embedding.android.FlutterFragmentActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugins.GeneratedPluginRegistrant;

public class MainActivity extends FlutterFragmentActivity {

    private static final String CHANNEL = "flutter.my.channel";
    private MethodChannel channel;
    private final String TAG = "idvoice.native";
    // private VoiceTemplate[] voices = new VoiceTemplate[3];

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        GeneratedPluginRegistrant.registerWith(flutterEngine);

        channel = new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL);

        channel.setMethodCallHandler((call, result) -> {

            Log.w(TAG, "RECEIVE method=" + call.method);
            // Note: this method is invoked on the main thread.
            if (call.method.equals("hello")) {
                result.success("Hallo Juga");
                // result.error("UNAVAILABLE", "Battery level not available.", null);
            } else if (call.method.equals("toast")) {
                Toast.makeText(getApplicationContext(), "Flutter Toast", Toast.LENGTH_LONG).show();
                result.success("ok");
            } else if (call.method.equals("enroll")) {
                String fileName = call.argument("file");
                String groupName = call.argument("group");

                File file = new File(fileName);

                result.success("ok");

                // Toast.makeText(getApplicationContext(), "Face " + groupName + " registered",
                // Toast.LENGTH_SHORT)
                // .show();
            } else if (call.method.equals("verify")) {
                String fileName = call.argument("file");
                String score = call.argument("score.minimum");

                result.success("ret");
            } else if (call.method.equals("idvoice.group")) {
                String groupName = call.argument("group");
                List<TrnEnroll> list = DataUtil.getEnrollList(getApplicationContext(), groupName);
                Gson gson = new Gson();
                String json = gson.toJson(list);
                result.success(json);
            } else if (call.method.equals("idvoice.enroll.voice")) {
                String score = call.argument("score.minimum");
                String group = call.argument("group");
                Integer counter = call.argument("counter");

                Log.e(TAG, "counter adalah " + counter);

                float minScore = score == null || score.trim().length() < 1 || score.equals("null") ? 0.7f
                        : Float.parseFloat(score);

                // 1) Init antispoofing and verification engines
                EngineManager engine = EngineManager.getInstance();
                engine.init(this);

                showEnrollDialog(engine, group, 0);

                // Intent i = new Intent(getApplicationContext(), ActivityLive.class);
                // i.putExtra(ActivityLive.PARAM_SCORE, minScore);
                // startActivityForResult(i, ActivityLive.REQUEST_LIVE);

                Log.e(TAG, " startActivityForResult(i, REQUEST_LIVE);");
                result.success("...");
            } else if (call.method.equals("idvoice.audio.live")) {
                //verify
                // 1) Init antispoofing and verification engines
                EngineManager engine = EngineManager.getInstance();
                engine.init(this);

                showVerifyDialog(engine, result);

            } else if (call.method.equals("idvoice.merge.voice")) {
                String group = call.argument("group");
                // Integer counter = call.argument("counter");

                List<TrnEnroll> list = DataUtil.getEnrollList(getApplicationContext(), group);

                VoiceTemplate[] voices = new VoiceTemplate[list.size()];

                for (int i = 0; i < list.size(); i++) {
                    voices[i] = VoiceTemplate.loadFromFile(list.get(i).getFileName());

                    // delete
                    DataUtil.deleteFromDB(getApplicationContext(), list.get(i).getUid());
                }

                // EngineManager engine = EngineManager.getInstance();
                // engine.init(this);

                TrnEnroll newEnroll = new TrnEnroll();
                newEnroll.setUid(java.util.UUID.randomUUID().toString());
                newEnroll.setCreatedDate(new Date().getTime());
                newEnroll.setFullName(group);
                newEnroll.setGroupName(group);

                File cacheFile = null;
                try {
                    cacheFile = createTempAudioFile();
                    newEnroll.setFileName(cacheFile.getPath());

                    VoiceTemplate templateMerged = EngineManager.getInstance().voiceTemplateFactory
                            .mergeVoiceTemplates(voices);
                    templateMerged.saveToFile(newEnroll.getFileName());

                    DataUtil.saveToDB(getApplicationContext(), new File(newEnroll.getFileName()), group);
                    result.success("...");

                } catch (IOException e) {
                    e.printStackTrace();
                    result.error("500", e.getMessage(), null);
                }

            } else {
                result.notImplemented();

                Toast.makeText(getApplicationContext(), "Not Implemented", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void showEnrollDialog(final EngineManager engine, final String groupName, final int counter) {
        FragmentManager fm = getSupportFragmentManager();
        RecordDialog editNameDialogFragment = RecordDialog.newInstance("Some Title");

        editNameDialogFragment.setOnStopListener(new OnStopRecording() {
            @Override
            public void onStop(AudioRecord recordObject) {
                // Create voice template and store it in array
                VoiceTemplate voice = engine.voiceTemplateFactory.createVoiceTemplate(recordObject.getSamples(),
                        recordObject.getSampleRate());
                // voices[counter] =
                // engine.voiceTemplateFactory.createVoiceTemplate(recordObject.getSamples(),
                // recordObject.getSampleRate());

                if (counter <= 1) {
                    String message = String.format(getString(R.string.recording_done), counter + 1);
                    Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                } else {
                    // counter = 2;
                    Toast.makeText(getApplicationContext(), R.string.enrollment_done, Toast.LENGTH_SHORT).show();
                    // loaderView.setVisibility(View.VISIBLE);

                    // Timer timer = new Timer();
                    // timer.schedule(new TimerTask() {
                    // @Override
                    // public void run() {
                    //// if (getActivity() != null) {
                    // runOnUiThread(new Runnable() {
                    // @Override
                    // public void run() {
                    // // registrasi 3x telah lengkap
                    // getFragmentManager().popBackStack();
                    // }
                    // });
                    //// }
                    // }
                    // }, 2000);
                }

                // changeCounter(counter + 1);

                TrnEnroll row = null;
                try {
                    row = saveUser(voice, groupName);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                // kirim balik ke flutter
                // TrnEnroll row = DataUtil.getEnroll(getApplicationContext(), uid);
                if (row == null)
                    return;

                String json = new Gson().toJson(row);
                channel.invokeMethod("idvoice.add.result", json);
            }
        });

        editNameDialogFragment.show(fm, "fragment_edit_name");
    }

    private void showVerifyDialog(final EngineManager engine, final MethodChannel.Result result) {
        FragmentManager fm = getSupportFragmentManager();
        RecordDialog editNameDialogFragment = RecordDialog.newInstance("Some Title");

        editNameDialogFragment.setOnStopListener(new OnStopRecording() {
            @Override
            public void onStop(AudioRecord recordObject) {

                        // 1) Get engines
                        EngineManager engineManager = EngineManager.getInstance();

                        // 2.1) Create voice template from verification audio
                        VoiceTemplate verifyTemplate = engineManager.voiceTemplateFactory.createVoiceTemplate(
                                recordObject.getSamples(),
                                recordObject.getSampleRate());

                        // 2.2) Retrieve enrollment voice template from shared preferences
                        List<TrnEnroll> list = DataUtil.getAllEnroll(getApplicationContext());

                        float max = 0;
                        TrnEnroll mostMatch = null;
                        for (int i = 0; i < list.size(); i++) {
                            TrnEnroll e = list.get(i);

                            if (e.getFileName() == null || e.getFileName().length() < 1)
                                continue;

                            VoiceTemplate _audioFile = VoiceTemplate.loadFromFile(e.getFileName());

                            VerifyResult verificationResult = engineManager.voiceTemplateMatcher.matchVoiceTemplates(
                                    _audioFile, verifyTemplate);

                            if (verificationResult.getProbability() > max) {
                                max = verificationResult.getProbability();
                                mostMatch = e;
                            }
                        }

//                        VoiceTemplate enrollTemplate = VoiceTemplate.deserialize(Prefs.getInstance().getVoiceTemplate());

                        // 2.3) Match voice templates
//                        VerifyResult verificationResult = engineManager.voiceTemplateMatcher.matchVoiceTemplates(
//                                enrollTemplate, verifyTemplate);

                        // 3) Pack bundle with retrieved scores
//                        final Bundle bundle = new Bundle();
//                        bundle.putFloat("VERIFICATION_SCORE", verificationResult.getProbability());

                        // 4) Show results dialog
                        if (mostMatch == null) {
                            channel.invokeMethod("idvoice.audio.live.result", "no match");
                        } else {
                            String result = "Hello " + mostMatch.getFullName() + "(" + max + ")";
                            channel.invokeMethod("idvoice.audio.live.result", result);
                        }

                        result.success("...");
//                        getActivity().runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//                                loaderView.setVisibility(View.GONE);
//                                StatisticsDialog dialog = StatisticsDialog.newInstance(bundle);
//                                dialog.show(getFragmentManager(), "STATISTICS");
//                            }
//                        });
//                    }
//                });

                // Create voice template and store it in array
//                VoiceTemplate voice = engine.voiceTemplateFactory.createVoiceTemplate(recordObject.getSamples(),
//                        recordObject.getSampleRate());
//
//                TrnEnroll row = null;
//                try {
//                    row = saveUser(voice, groupName);
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//
//                // kirim balik ke flutter
//                // TrnEnroll row = DataUtil.getEnroll(getApplicationContext(), uid);
//                if (row == null)
//                    return;
//
//                String json = new Gson().toJson(row);
//                channel.invokeMethod("idvoice.audio.live.result", json);
            }
        });

        editNameDialogFragment.show(fm, "fragment_edit_name");
    }


    private File createTempAudioFile() throws IOException {
        File cacheFile = File.createTempFile("tmp", ".audio");
        // clean up the last one
        if (cacheFile.exists())
            cacheFile.delete();

        // must create file first
        cacheFile.getParentFile().mkdirs();
        cacheFile.createNewFile();

        // Uri uriSavedImage = null; //
        // content://id.co.ppu.collectionfast2.provider/external_files/RadanaCache/cache/poaDefault_demo_71000000008115.jpg
        // uriSavedImage = FileProvider.getUriForFile(this,
        // BuildConfig.APPLICATION_ID + ".provider",
        // cacheFile);

        return cacheFile;
    }

    private TrnEnroll saveUser(VoiceTemplate voice, String groupName) throws IOException {
        // 1) Merge created templates into one
        // ini salah krn merge hny kalo udah terkumpul 3 voice
        // VoiceTemplate templateMerged =
        // EngineManager.getInstance().voiceTemplateFactory.mergeVoiceTemplates(voices);

        /*
         * 2) Save template to shared preferences (there is also an option to store
         * voice template in file via "templateMerged.saveToFile(<path>)")
         */

        File cacheFile = createTempAudioFile();

        Log.i(TAG, "saving to " + cacheFile.getPath());

        voice.saveToFile(cacheFile.getPath());
        // templateMerged.saveToFile(file);

        return DataUtil.saveToDB(getApplicationContext(), cacheFile, groupName);
        // Prefs.getInstance().setVoiceTemplate(templateMerged.serialize());
    }
}

package com.ppu.idvoice.dialogs;

public interface OnSpeechLengthUpdate {
    void onSpeechLengthUpdate(float speechLength);
}
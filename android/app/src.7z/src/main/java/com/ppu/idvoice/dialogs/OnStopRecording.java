package com.ppu.idvoice.dialogs;

import com.ppu.idvoice.AudioRecord;

public interface OnStopRecording {
    void onStop(AudioRecord recordObject);
}

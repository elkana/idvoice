package com.ppu.idvoice.utils;

import android.content.SharedPreferences;
import android.util.Base64;

/*
 * SharedPreferences wrapper
 */
public class Prefs {

    private static final String VOICE_TEMPLATE = "VOICE_TEMPLATE";

    private SharedPreferences preferenceManager;

    private static Prefs instance;

    private Prefs() {}

    public static Prefs getInstance() {
        if (instance == null) {
            instance = new Prefs();
        }

        return instance;
    }

    public void init(SharedPreferences preferenceManager) {
        this.preferenceManager = preferenceManager;
    }

    public Prefs(SharedPreferences manager) {
        preferenceManager = manager;
    }

    public byte[] getVoiceTemplate() {
       String encodedBytes = preferenceManager.getString(VOICE_TEMPLATE, "");

       if (!encodedBytes.equals("")) {
           return Base64.decode(encodedBytes, Base64.NO_WRAP);
       } else {
           return null;
       }
    }

    public void setVoiceTemplate(byte[] voiceTemplate) {
        preferenceManager.edit().putString(VOICE_TEMPLATE, Base64.encodeToString(voiceTemplate, Base64.NO_WRAP)).apply();
    }
}
